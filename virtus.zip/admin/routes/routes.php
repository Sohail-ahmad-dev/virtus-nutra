<?php

// Define an array with the menu items and their URLs
$menu_items = array(
    'Dashboard' => 'index.php',
    'Products' => 'products.php',
);


?>