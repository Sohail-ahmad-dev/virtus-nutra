<footer>
                <div class="wrapper">
                    <div class="foot-top"> <img src="images/13d1d5.png" class="unleash">
                        <div class="foot-award"> <img src="images/34fbfb.png"> </div>
                    </div>
                    <div class="footer-nav">
                        <div class="footer-col">
                            <ul>
                                <li><a href="terms.php">Terms & Conditions</a></li>
                                <li><a href="privacy.php">Privacy Policy</a></li>
                                <li><a href="sms.php">SMS Terms & Conditions</a></li>
                                <li><a href="contact-us.php">Contact Us</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="secure-badges"> <span><img style="position: relative;top: 13px;" width="100" height="58" border="0" src="images/norton.png"></span> <span id="mcafee" title="McAfee Secure sites help keep you safe from identity theft, credit card fraud, spyware, spam, viruses and online scams"><img width="115" height="32" border="0" src="images/12.gif" alt="McAfee Secure sites help keep you safe from identity theft, credit card fraud, spyware, spam, viruses and online scams" oncontextmenu="alert('Copying Prohibited by Law - McAfee Secure is a Trademark of McAfee, Inc.'); return false;"></span> <img src="images/badae3.png" class="secure"> </div>
                    <div class="foot-bot">
                        <p>These statements made on this website have not been evaluated by the Food and Drug Administration. The FDA only evaluates foods and drugs, not supplements like these products. These products are not intended to diagnose, treat, cure, or prevent any disease.</p>
                        <p>Copyright <sup>&copy;</sup> 2018 Virtus Nutra, LLC.  All rights reserved.</p>
                    </div>
                </div>
            </footer>
<script src="js/jquery-3.1.1.min.js"></script>
<script src="js/shoppingCart.js"></script>
<script>
    $(document).ready(function () {
        getShoppingCart();
    });
</script>
