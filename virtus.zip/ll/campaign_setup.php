<?php

include('config.php');

include('limelight.php');

//URL of Site
//$campaign_path           = 'http://localhost/cm/';
$campaign_path = 'https://virtusnutra.com/';
$folder_name = '';
///Limelight Campaign number
$campaign_id = 1141;
///Limelight  Prepaid Campaign number if regular Decline
//$prepaid_campaign_id    =  '';
$product_id = 442;
$shipping_id = 4; //4.95
//Limelight Campaign number for downsell 
$downsell_shipping_id = 0; //1.95
$product_price = 0.00;
//$downsell_campaign_id    = 15;
//$country				 = 'US';
//$currency_text           = 'AUD';
//$currency_symbol         = 'A$';
//$calculator              = 'block'; // block , none //
$cdn_image_path = '';
$upsell_campaign_id = 45;
$upsell_product_id = 41;
//$upsell_shipping_id		 = 18;
$upsell_shipping_id = 1;
//$prepaid_upsell_campaign_id    =  122;
?>