<?php

date_default_timezone_set('America/New_York');

session_start();
$cnd_img_path = '';
//$ssl_url = 'http://localhost/cm/';
$ssl_url = 'https://virtusnutra.com/';

$cloudfont_path = '';
$limelight_api_username = 'www.mucrt.com';
$limelight_api_password = 'SEm7QmDWHzZjDe';
$limelight_crm_instance = 'mucrt.limelightcrm.com';





//function safeRequest($strGet) {

	  // $strGet = preg_replace("/[^a-zA-Z0-9(\040)-\_@.]*/m","",$strGet);

     // $strGet = str_ireplace("javascript","",$strGet);

     // $strGet = str_ireplace("encode","",$strGet);

    //  $strGet = str_ireplace("decode","",$strGet);

     // return trim($strGet);

//}







